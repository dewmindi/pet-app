import 'package:firstapp/widgets/addVaccine.dart';
import 'package:flutter/material.dart';

class PetProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blue.shade400,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back,),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Text(
                'Help',
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
            ),
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Profile Section
          Container(
            color: Colors.blue.shade400,
            padding: EdgeInsets.symmetric(vertical: 20),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage('assets/pet.jpg'), // Your pet image
                ),
                SizedBox(height: 10),
                Text(
                  'Asi',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  '2 YEARS OLD DOG',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.white.withOpacity(0.8),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 20),
          // Tabs for Reports, Appointments, Vaccines
          Container(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildTabItem(context, 'Reports'),
                _buildTabItem(context, 'Appointments'),
                _buildTabItem(context, 'Vaccines', isActive: true),
              ],
            ),
          ),
          SizedBox(height: 20),
          // Vaccine List
          Expanded(
            child: ListView(
              padding: EdgeInsets.symmetric(horizontal: 16),
              children: [
                _buildVaccineCard('DHPP vaccine', 'EVERY 1 YEAR · NEXT 24 MAY'),
                _buildVaccineCard('Rabies vaccine', 'EVERY 2 YEAR · NEXT 17 AUG'),
                _buildVaccineCard('DHPP vaccine', 'EVERY 1 YEAR · NEXT 24 MAY'),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(context,
          MaterialPageRoute(builder: (context)=>(VaccineDetailPage())));
        },
        backgroundColor: Colors.blue.shade400,
        child: Icon(Icons.add),
      ),
    );
  }

  // Function to build the tab item
  Widget _buildTabItem(BuildContext context, String title, {bool isActive = false}) {
    return GestureDetector(
      onTap: () {
        // Handle tab switch
      },
      child: Column(
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 16,
              color: isActive ? Colors.blue.shade400 : Colors.grey.shade500,
              fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          if (isActive)
            Container(
              height: 3,
              width: 60,
              margin: EdgeInsets.only(top: 4),
              color: Colors.blue.shade400,
            )
        ],
      ),
    );
  }

  // Function to build vaccine card
  Widget _buildVaccineCard(String vaccineName, String vaccineDetails) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      elevation: 2,
      margin: EdgeInsets.symmetric(vertical: 10),
      child: ListTile(
        leading: Icon(Icons.vaccines, color: Colors.blue.shade400, size: 36),
        title: Text(
          vaccineName,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: Colors.black87,
          ),
        ),
        subtitle: Text(
          vaccineDetails,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey.shade600,
          ),
        ),
      ),
    );
  }
}
